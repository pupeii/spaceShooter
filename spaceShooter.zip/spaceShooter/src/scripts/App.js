import * as PIXI from 'pixi.js';
import shipImage from "../sprites/ship.png";
import meteorImage from "../sprites/meteor.png";
import bossImage from "../sprites/boss.png";
import bg from "../sprites/bg.png";

export class App {
    run() {
       

const app = new PIXI.Application({
  width: 1280,
  height: 720,
  backgroundColor: 0x1099bb,
});

document.body.appendChild(app.view);

const shipTexture = PIXI.Texture.from(shipImage);
const meteorTexture = PIXI.Texture.from(meteorImage);
const bossTexture = PIXI.Texture.from(bossImage);
const backgroundTexture = PIXI.Texture.from(bg);

// Create two instances of the background
const background1 = new PIXI.Sprite(backgroundTexture);
const background2 = new PIXI.Sprite(backgroundTexture);

background1.width = app.screen.width;
background1.height = app.screen.height;
background2.width = app.screen.width;
background2.height = app.screen.height;

background1.y = 0;
background2.y = -app.screen.height;

app.stage.addChild(background1);
app.stage.addChild(background2);


const ship = new PIXI.Sprite(shipTexture);
ship.width = 100;
ship.height = 100;
ship.x = (app.view.width - ship.width) / 2;
ship.y = app.view.height - ship.height - 20;
app.stage.addChild(ship);

const bullets = [];
const meteors = [];

let totalBulletCount = 0;
const maxBullets = 10;
let destroyedMeteorsCount = 0;
let currentLevel = 1;
let areMeteorsMoving = true;
let bossHp = 4;
const bulletCountDisplay = document.getElementById("bulletCount");
const destroyedMeteorsDisplay = document.getElementById("destroyedMeteorsCount");
const bossHpDisplay = document.getElementById("boss");
const levelDisplay = document.getElementById("level");
const bossDirectionChance = 0.01  ; 
const healthBar = [];

let timer = 60;
const timerText = new PIXI.Text(`Time: ${timer}`, {
    fontFamily: 'Press Start 2P',
    fontSize: 16,
    fill: 0xffffff,
    align: 'center'
});
timerText.x = app.screen.width - 150;
timerText.y = 10;
app.stage.addChild(timerText);


const createhealthBar = boss => {
  healthBar.forEach(indicator => app.stage.removeChild(indicator));
  healthBar.length = 0;

  const numberOfPieces = 4;

  for (let i = 0; i < numberOfPieces; i++) {
    const healthPiece = new PIXI.Graphics();
    healthPiece.beginFill(0xff0000);
    healthPiece.drawRect(10, 10, 10, 10);
    healthPiece.endFill();

    healthPiece.x = boss.x + i * 200;
    healthPiece.y = boss.y - 20;

    healthBar.push(healthPiece);
    app.stage.addChild(healthPiece);
  }
};

const updatehealthBar = () => {
  if (healthBar.length > 0) {
    const healthPiece = healthBar.pop();
    app.stage.removeChild(healthPiece);
  }
};

const updateDisplays = () => {
  bulletCountDisplay.textContent = `Ammo: ${totalBulletCount} / 10`;
  levelDisplay.textContent = `Level ${currentLevel}`;

  if (currentLevel === 1) {
    destroyedMeteorsDisplay.textContent = `Meteors: ${destroyedMeteorsCount} / 4`;
    bossHpDisplay.textContent = ``;
  }

  if (currentLevel === 2) {
    bossHpDisplay.textContent = `BOSS: ${bossHp} / 4`;
    destroyedMeteorsDisplay.textContent = ``;
  }
};

const createBullet = () => {
  if (totalBulletCount >= maxBullets) return;

  const bullet = new PIXI.Graphics();
  bullet.beginFill(0x00ff0e);
  bullet.drawRect(0, 0, 5, 20);
  bullet.endFill();

  bullet.x = ship.x + ship.width / 2 - 2.5;
  bullet.y = ship.y;

  bullets.push(bullet);
  app.stage.addChild(bullet);
  totalBulletCount++;
  updateDisplays();
};

const createMeteor = (simple = true) => {
  const meteor = new PIXI.Sprite(simple ? meteorTexture : bossTexture);
  meteor.width = simple ? 50 : 100;
  meteor.height = simple ? 50 : 100;
  meteor.x = Math.random() * (app.view.width - meteor.width);
  meteor.y = -meteor.height;

  meteor.velocityX = Math.random() > 0.5 ? 5 : -5; 

  if (!simple) {
    meteor.y = app.view.height / 2 - meteor.height / 2;
  }

  meteors.push(meteor);
  app.stage.addChild(meteor);
};

window.addEventListener("keydown", event => {
  switch (event.key) {
    case "ArrowLeft":
      ship.x -= 40;
      break;
    case "ArrowRight":
      ship.x += 40;
      break;
    case " ":
      createBullet();
      break;
  }
});

const checkCollisions = () => {
  for (let i = bullets.length - 1; i >= 0; i--) {
    const bullet = bullets[i];

    for (let j = meteors.length - 1; j >= 0; j--) {
      const meteor = meteors[j];

      if (bullet.getBounds().intersects(meteor.getBounds())) {
        if (currentLevel === 2 && meteor.texture === bossTexture) {
          bossHp--;
          updatehealthBar();

          if (bossHp <= 0) {
            app.stage.removeChild(meteor);
            meteors.splice(j, 1);
            goToNextLevel();
          }
        } else if (currentLevel === 1) {
          app.stage.removeChild(meteor);
          meteors.splice(j, 1);
          destroyedMeteorsCount++;
        }

        app.stage.removeChild(bullet);
        bullets.splice(i, 1);
        updateDisplays();
        break;
      }
    }
  }
};

const goToNextLevel = () => {
  bullets.forEach(bullet => app.stage.removeChild(bullet));
  meteors.forEach(meteor => app.stage.removeChild(meteor));
  bullets.length = 0;
  meteors.length = 0;

  // Stop the timer and remove it from the stage
  app.ticker.remove(timerText); // Assuming updateTimer is the function updating the timer
  app.stage.removeChild(timerText);

  if (currentLevel === 1) {
    currentLevel = 2;
    destroyedMeteorsCount = 0;
    totalBulletCount = 0;
    areMeteorsMoving = false;
    updateDisplays();

    createMeteor(false);
    createhealthBar(meteors[0]);
  } else {
    showGameOverModal("YOU WIN!");
    app.ticker.stop();
  }
};

const showGameOverModal = message => {
  const modal = document.createElement("div");
  modal.style.position = "absolute";
  modal.style.top = "50%";
  modal.style.left = "50%";
  modal.style.transform = "translate(-50%, -50%)";
  modal.style.backgroundColor = "rgba(0, 0, 0, 0.8)";
  modal.style.color = "white";
  modal.style.padding = "20px";
  modal.style.borderRadius = "10px";
  modal.style.textAlign = "center";
  modal.style.fontSize = "24px";
  modal.style.fontFamily = "'Press Start 2P', sans-serif";
  modal.textContent = message;

  const button = document.createElement("button");
  button.textContent = "Restart";
  button.style.display = "block";
  button.style.margin = "20px auto 0";
  button.style.padding = "10px 20px";
  button.style.fontSize = "18px";
  modal.style.fontFamily = "'Press Start 2P', sans-serif";
  button.addEventListener("click", () => {
    document.location.reload();
  });

  modal.appendChild(button);
  document.body.appendChild(modal);
};

const checkGameOver = () => {
  if (currentLevel === 1) {
    if (totalBulletCount === maxBullets && bullets.length === 0 && destroyedMeteorsCount < 4) {
      showGameOverModal("YOU LOSE");
      return true; 
    }

    if (destroyedMeteorsCount >= 4) {
      goToNextLevel();
      return false; 
    }
  } else if (currentLevel === 2) {
    if (totalBulletCount === maxBullets && bullets.length === 0) {
      showGameOverModal("YOU LOSE");
      return true; 
    }

    if (meteors.length === 0) {
      goToNextLevel();
      return false; 
    }
  }

  return false; 
};

app.ticker.add(() => {

     // Update the timer
     if (app.ticker.lastTime % 1000 < 16.67) { // Approximately every second
        timer--;
        timerText.text = `Time: ${timer}`;
        if (timer <= 0 && currentLevel === 1) {
            app.ticker.stop(); 
            showGameOverModal("YOU LOSE");

        }
    }

     // Scroll the background
     background1.y += 1;
     background2.y += 1;

     if (background1.y >= app.screen.height) {
         background1.y = -app.screen.height;
     }
     if (background2.y >= app.screen.height) {
         background2.y = -app.screen.height;
     }


  if (checkGameOver()) {
    app.ticker.stop(); 
    return;
  }

  if (ship.x < 0) {
    ship.x = 0;
  } else if (ship.x > app.view.width - ship.width) {
    ship.x = app.view.width - ship.width;
  }

  for (let i = bullets.length - 1; i >= 0; i--) {
    const bullet = bullets[i];
    bullet.y -= 10;

    if (bullet.y < 0) {
      app.stage.removeChild(bullet);
      bullets.splice(i, 1);
    }
  }

  for (let i = meteors.length - 1; i >= 0; i--) {
    const meteor = meteors[i];

    if (areMeteorsMoving) {
      meteor.y += 1;
    } else {
      meteor.x += meteor.velocityX;

      if (Math.random() < bossDirectionChance) {
        meteor.velocityX = -meteor.velocityX;
      }

      if (meteor.x < 0 || meteor.x > app.view.width - meteor.width) {
        meteor.velocityX = -meteor.velocityX;
      }

      if (meteor.texture === bossTexture) {
        healthBar.forEach((piece, index) => {
          piece.x = meteor.x + index * (50 + 5);
        });
      }
    }

    if (meteor.y > app.view.height) {
      app.stage.removeChild(meteor);
      meteors.splice(i, 1);
    }
  }

  if (Math.random() < 0.02 && areMeteorsMoving) {
    createMeteor();
  }

  checkCollisions();
});

    }

   
}
